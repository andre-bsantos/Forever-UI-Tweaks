
/pframescale 0.75   Set the Player Frame to 75% size and save it.
/pframescale show   Show the saved scale.
/pframescale reset  Restore 1.00x.
