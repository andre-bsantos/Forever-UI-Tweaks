local DEFAULT_SCALE = 1.0
local MIN_SCALE = 0.25
local MAX_SCALE = 2.0

-- Keep the scale when upgrading from the original database name, then use
-- ForeverPersonalUIAdjustmentsDB for all future saves.
if type(ForeverPersonalUIAdjustmentsDB) ~= "table" then
    ForeverPersonalUIAdjustmentsDB = type(PlayerFrameScaleDB) == "table"
        and PlayerFrameScaleDB or {}
end
PlayerFrameScaleDB = nil

local function printMessage(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffForever Personal UI Adjustments:|r " .. message)
end

local function applyScale()
    if InCombatLockdown and InCombatLockdown() then
        return false
    end

    if not PlayerFrame or not PlayerFrame.SetScale then
        return false
    end

    local scale = tonumber(ForeverPersonalUIAdjustmentsDB.scale) or DEFAULT_SCALE
    scale = math.max(MIN_SCALE, math.min(MAX_SCALE, scale))

    local ok, err = pcall(PlayerFrame.SetScale, PlayerFrame, scale)
    if not ok then
        printMessage("could not scale the Player Frame: " .. tostring(err))
        return false
    end

    return true
end

local function applyMiniLevelMarker()
    if InCombatLockdown and InCombatLockdown() then
        return false
    end
    if not PlayerFrame or not PlayerLevelText then
        return false
    end
    local bbf = BBF
    local db = BetterBlizzFramesDB
    local hiddenFrame = bbf and bbf.hiddenFrame
    local isMini = db and db.useMiniPlayerFrame
    local isHiddenByBBF = hiddenFrame and PlayerLevelText:GetParent() == hiddenFrame

    -- BBF's Mini Player Frame deliberately reparents this text to a hidden frame.
    if not isMini and not isHiddenByBBF then
        return false
    end

    local contentMain = PlayerFrame.PlayerFrameContent
        and PlayerFrame.PlayerFrameContent.PlayerFrameContentMain
    if not contentMain then
        return false
    end

    if PlayerLevelText:GetParent() ~= contentMain then
        PlayerLevelText:SetParent(contentMain)
    end
    PlayerLevelText:SetAlpha(1)
    PlayerLevelText:Show()

    -- BBF's HD level circle normally belongs to ClassicFrame, which Mini hides.
    -- Move it to the visible player container, keeping it centered on the number.
    local container = PlayerFrame.PlayerFrameContainer or PlayerFrame
    local classicFrame = PlayerFrame.ClassicFrame
    local ring = classicFrame and classicFrame.HDLevelCircle

    if not ring and bbf and type(bbf.SetClassicHDLevelRing) == "function" then
        pcall(bbf.SetClassicHDLevelRing, PlayerFrame, true)
        ring = classicFrame and classicFrame.HDLevelCircle
    end

    if not ring then
        ring = container.PlayerFrameScaleLevelCircle
        if not ring then
            ring = container:CreateTexture("PlayerFrameScaleLevelCircle", "OVERLAY", nil, 5)
            container.PlayerFrameScaleLevelCircle = ring
            ring:SetAtlas("hud-PlayerFrame-levelring")
            ring:SetSize(38, 32)
        end
    else
        ring.bbfEnabled = true
        if ring:GetParent() ~= container then
            ring:SetParent(container)
        end
    end

    ring:ClearAllPoints()
    ring:SetPoint("CENTER", PlayerLevelText, "CENTER", 0.5, -1.5)
    ring:SetAlpha(1)
    ring:Show()

    if ring.Refresh then
        ring.Refresh()
    end

    return true
end

local function applySettings()
    applyScale()
    applyMiniLevelMarker()
end

local function scheduleLevelMarker()
    C_Timer.After(0, applyMiniLevelMarker)
    C_Timer.After(0.5, applyMiniLevelMarker)
    C_Timer.After(1.5, applyMiniLevelMarker)
end

-- BBF can reparent PlayerLevelText again after its MiniFrame setup. Restore it
-- whenever that happens, while respecting BBF's explicit level-hide settings.
if PlayerLevelText and hooksecurefunc then
    hooksecurefunc(PlayerLevelText, "SetParent", function(frame)
        local db = BetterBlizzFramesDB
        local hiddenFrame = BBF and BBF.hiddenFrame
        local parent = frame:GetParent()
        local contentMain = PlayerFrame and PlayerFrame.PlayerFrameContent
            and PlayerFrame.PlayerFrameContent.PlayerFrameContentMain

        if contentMain and parent ~= contentMain
            and ((db and db.useMiniPlayerFrame) or (hiddenFrame and parent == hiddenFrame)) then
            C_Timer.After(0, applyMiniLevelMarker)
        end
    end)
end

-- Run after BBF's MiniFrame function so the level marker is restored after
-- BBF moves its text and frame art onto the hidden frame.
if BBF and type(BBF.MiniFrame) == "function" then
    hooksecurefunc(BBF, "MiniFrame", function(frame)
        if frame == PlayerFrame then
            scheduleLevelMarker()
        end
    end)
end

SLASH_PLAYERFRAMESCALE1 = "/pframescale"
SlashCmdList.PLAYERFRAMESCALE = function(message)
    local command = (message or ""):match("^%s*(.-)%s*$")
    command = command:lower()

    if command == "" or command == "show" then
        printMessage(string.format(
            "current scale: %.2fx. Use /pframescale <number> (0.25–2.00) or /pframescale reset.",
            tonumber(ForeverPersonalUIAdjustmentsDB.scale) or DEFAULT_SCALE
        ))
    elseif command == "reset" then
        ForeverPersonalUIAdjustmentsDB.scale = DEFAULT_SCALE
        applyScale()
        printMessage("scale reset to 1.00x.")
    else
        local scale = tonumber(command)
        if not scale then
            printMessage("usage: /pframescale <number>, /pframescale reset, or /pframescale show")
            return
        end

        scale = math.max(MIN_SCALE, math.min(MAX_SCALE, scale))
        ForeverPersonalUIAdjustmentsDB.scale = scale

        if applyScale() then
            printMessage(string.format("set to %.2fx and saved.", scale))
        elseif InCombatLockdown and InCombatLockdown() then
            printMessage(string.format("%.2fx saved; it will apply after combat.", scale))
        else
            printMessage(string.format("%.2fx saved; waiting for the Player Frame to load.", scale))
        end
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:SetScript("OnEvent", function(_, event)
    if type(ForeverPersonalUIAdjustmentsDB) ~= "table" then
        ForeverPersonalUIAdjustmentsDB = {}
    end
    if ForeverPersonalUIAdjustmentsDB.scale == nil then
        ForeverPersonalUIAdjustmentsDB.scale = DEFAULT_SCALE
    end

    applySettings()

    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        scheduleLevelMarker()
    end
end)

-- Keep the minimap and its child controls behind the player frame.
 local function pfsSetTreeStrata(frame, strata, visited)
    if not frame or visited[frame] then return end
    visited[frame] = true

    if frame.SetFrameStrata then
        pcall(frame.SetFrameStrata, frame, strata)
    end

    if frame.GetChildren then
        for _, child in pairs({ frame:GetChildren() }) do
            pfsSetTreeStrata(child, strata, visited)
        end
    end
end

local function pfsApplyLayers()
    if InCombatLockdown and InCombatLockdown() then return end

    pfsSetTreeStrata(PlayerFrame, "HIGH", {})

    local mapLevel = 0
    if MinimapCluster and MinimapCluster.GetFrameLevel then
        mapLevel = math.max(mapLevel, MinimapCluster:GetFrameLevel())
    end
    if Minimap and Minimap.GetFrameLevel then
        mapLevel = math.max(mapLevel, Minimap:GetFrameLevel())
    end

    if PlayerFrame and PlayerFrame.GetFrameLevel
        and PlayerFrame.SetFrameLevel
        and PlayerFrame:GetFrameLevel() <= mapLevel then
        pcall(PlayerFrame.SetFrameLevel, PlayerFrame, mapLevel + 10)
    end
end

local function pfsScheduleRefresh()
    C_Timer.After(0, function()
        applyScale()
        pfsApplyLayers()
    end)
    C_Timer.After(0.5, function()
        applyScale()
        pfsApplyLayers()
    end)
    C_Timer.After(1.5, function()
        applyScale()
        pfsApplyLayers()
    end)
end

local pfsLayerEvents = CreateFrame("Frame")
pfsLayerEvents:RegisterEvent("PLAYER_LOGIN")
pfsLayerEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
pfsLayerEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
pfsLayerEvents:SetScript("OnEvent", pfsScheduleRefresh)

if BBF and type(BBF.MiniFrame) == "function" then
    hooksecurefunc(BBF, "MiniFrame", function(frame)
        if frame == PlayerFrame then
            pfsScheduleRefresh()
        end
    end)
end

-- Remove decorative quest tracker art and set tracker text to 11.
local function applyQuestTrackerStyle()
    local tracker = ObjectiveTrackerFrame
    if not tracker then return end

    local function hide(texture)
        if texture and texture.Hide then
            texture:Hide()
        end
    end

    hide(tracker.NineSlice)
    hide(tracker.Background)

    if tracker.Header then
        hide(tracker.Header.Background)
    end

    -- Keep the header's collapse/expand control, but remove its label.
    -- Blizzard has moved this FontString between tracker builds, so match
    -- the displayed text instead of relying on one field name.
    local allObjectivesLabel = ALL_OBJECTIVES or "All Objectives"
    local function hideAllObjectivesLabel(frame, seen)
        if not frame or seen[frame] then return end
        seen[frame] = true

        if frame.GetRegions then
            for _, region in pairs({ frame:GetRegions() }) do
                if region and region.GetObjectType
                    and region:GetObjectType() == "FontString"
                    and region.GetText then
                    local text = region:GetText()
                    if text == allObjectivesLabel or text == "All Objectives" then
                        region:Hide()
                    end
                end
            end
        end

        if frame.GetChildren then
            for _, child in pairs({ frame:GetChildren() }) do
                hideAllObjectivesLabel(child, seen)
            end
        end
    end
    hideAllObjectivesLabel(tracker.Header or tracker, {})

    local function setFontSize(frame, seen)
        if not frame or seen[frame] then return end
        seen[frame] = true

        if frame.GetRegions then
            for _, region in pairs({ frame:GetRegions() }) do
                if region and region.GetObjectType
                    and region:GetObjectType() == "FontString" then
                    local font, _, flags = region:GetFont()
                    if font then
                        region:SetFont(font, 11, flags)
                    end
                end
            end
        end

        if frame.GetChildren then
            for _, child in pairs({ frame:GetChildren() }) do
                setFontSize(child, seen)
            end
        end
    end

    setFontSize(tracker, {})

    for _, module in pairs(tracker.MODULES or tracker.modules or {}) do
        local header = module and module.Header
        if header then
            hide(header.Background)
            hide(header.TopLine)
            hide(header.BottomLine)
            hide(header.Divider)
            hide(header.Separator)
        end
    end
end

local questStyleHooked = false

local function refreshQuestTrackerStyle()
    applyQuestTrackerStyle()

    if ObjectiveTrackerFrame and ObjectiveTrackerFrame.Update
        and not questStyleHooked then
        questStyleHooked = true
        hooksecurefunc(ObjectiveTrackerFrame, "Update", function()
            C_Timer.After(0, applyQuestTrackerStyle)
        end)
    end
end

local questStyleEvents = CreateFrame("Frame")
questStyleEvents:RegisterEvent("PLAYER_LOGIN")
questStyleEvents:RegisterEvent("ADDON_LOADED")
questStyleEvents:RegisterEvent("QUEST_LOG_UPDATE")
questStyleEvents:SetScript("OnEvent", function()
    C_Timer.After(0, refreshQuestTrackerStyle)
end)

-- Hide the active experience/status bar while the Objective Tracker is
-- collapsed. Bartender4 wraps the Blizzard status bar in its own bar frame;
-- fall back to Blizzard's status-bar containers when Bartender is not active.
local objectivesBarHooked = false
local objectivesHiddenBars = {}

local function getObjectivesCollapsedState(tracker)
    if not tracker then return false end

    if tracker.IsCollapsed then
        local ok, collapsed = pcall(tracker.IsCollapsed, tracker)
        if ok and type(collapsed) == "boolean" then
            return collapsed
        end
    end

    return tracker.isCollapsed == true or tracker.collapsed == true
end

local function getExperienceBarFrames()
    local frames = {}
    local seen = {}

    local function add(frame)
        if frame and frame.Hide and frame.Show and not seen[frame] then
            seen[frame] = true
            frames[#frames + 1] = frame
        end
    end

    -- Bartender4 uses a wrapper frame around the Blizzard bar. Prefer that
    -- wrapper so its positioning and styling remain untouched when restored.
    local bartender = Bartender4
    if bartender and bartender.GetModule then
        for _, moduleName in ipairs({ "StatusTrackingBar", "XPBar" }) do
            local ok, module = pcall(bartender.GetModule, bartender, moduleName, true)
            if ok and module then
                add(module.bar)
            end
        end
    end

    -- Retail and older clients expose different names. The manager/container
    -- is the generic fallback; older clients use the individual XP bar.
    if #frames == 0 then
        add(_G.MainStatusTrackingBarContainer)
        add(_G.StatusTrackingBarManager)
        add(_G.MainMenuExpBar)
        add(_G.MainMenuBarExpBar)
    end

    return frames
end

local function updateExperienceBarForObjectives()
    if InCombatLockdown and InCombatLockdown() then
        return
    end

    local collapsed = getObjectivesCollapsedState(ObjectiveTrackerFrame)
    local bars = getExperienceBarFrames()

    if collapsed then
        for _, bar in ipairs(bars) do
            if not objectivesHiddenBars[bar] then
                objectivesHiddenBars[bar] = bar:IsShown()
            end
            if objectivesHiddenBars[bar] then
                pcall(bar.Hide, bar)
            end
        end
    else
        for bar, wasShown in pairs(objectivesHiddenBars) do
            if wasShown then
                pcall(bar.Show, bar)
            end
            objectivesHiddenBars[bar] = nil
        end
    end
end

local function scheduleExperienceBarUpdate()
    C_Timer.After(0, updateExperienceBarForObjectives)
    C_Timer.After(0.2, updateExperienceBarForObjectives)
end

local function hookObjectivesMinimizeButton()
    local tracker = ObjectiveTrackerFrame
    if not tracker then return end

    if not objectivesBarHooked then
        objectivesBarHooked = true

        if tracker.SetCollapsed then
            hooksecurefunc(tracker, "SetCollapsed", scheduleExperienceBarUpdate)
        end
    end

    local header = tracker.Header
    local headerMenu = tracker.HeaderMenu
    local buttons = {
        header and header.MinimizeButton,
        headerMenu and headerMenu.MinimizeButton,
    }

    for _, button in pairs(buttons) do
        if button and button.HookScript and not button.pfsExperienceBarHooked then
            button.pfsExperienceBarHooked = true
            button:HookScript("OnClick", scheduleExperienceBarUpdate)
        end
    end

    scheduleExperienceBarUpdate()
end

local objectivesBarEvents = CreateFrame("Frame")
objectivesBarEvents:RegisterEvent("PLAYER_LOGIN")
objectivesBarEvents:RegisterEvent("ADDON_LOADED")
objectivesBarEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
objectivesBarEvents:SetScript("OnEvent", function(_, event, addonName)
    if event == "ADDON_LOADED" and addonName ~= "Blizzard_ObjectiveTracker"
        and addonName ~= "Bartender4" then
        return
    end

    C_Timer.After(0, hookObjectivesMinimizeButton)
end)

-- Strip the decorative art from each Blizzard Damage Meter session window.
-- SetBackgroundAlpha did not affect the title-bar texture in the user's UI.
local damageMeterHooked = false

local function hideTextureRegions(frame)
    if not frame or not frame.GetRegions then return end

    for _, region in pairs({ frame:GetRegions() }) do
        if region and region.GetObjectType
            and region:GetObjectType() == "Texture" then
            region:Hide()
        end
    end
end

local function stripDamageMeterWindow(window)
    if not window then return end

    local function hide(texture)
        if texture and texture.Hide then texture:Hide() end
    end

    hide(window.Background)
    hide(window.NineSlice)
    hide(window.Border)
    hide(window.HeaderBackground)
    hideTextureRegions(window)

    local header = window.Header or window.TitleBar or window.HeaderFrame
    if header then
        hide(header.Background)
        hide(header.NineSlice)
        hide(header.Border)
        hideTextureRegions(header)
    end
end

local function removeDamageMeterArt()
    local meter = DamageMeter
    if meter then
        if meter.ForEachSessionWindow then
            meter:ForEachSessionWindow(stripDamageMeterWindow)
        end

        for i = 1, 3 do
            stripDamageMeterWindow(_G["DamageMeterSessionWindow" .. i])
        end

        if not damageMeterHooked and meter.SetupSessionWindow then
            damageMeterHooked = true
            hooksecurefunc(meter, "SetupSessionWindow", function()
                C_Timer.After(0, removeDamageMeterArt)
            end)
        end
    end
end

-- Remove the dark backing behind the minimap's zone name and move the mail
-- notification to the left of the tracking button.
local function applyMinimapAdjustments()
    local function hideZoneArt(frame, seen)
        if not frame or seen[frame] then return end
        seen[frame] = true

        if frame.GetObjectType and frame:GetObjectType() == "Texture" then
            frame:Hide()
            return
        end

        for _, key in ipairs({ "Background", "Backdrop", "NineSlice", "TextBackground" }) do
            local art = frame[key]
            if art and art.Hide then art:Hide() end
        end
        -- Some client builds draw this plate with a BackdropTemplate instead
        -- of texture regions, so remove that backdrop on the zone-label tree.
        if frame.SetBackdrop then
            pcall(frame.SetBackdrop, frame, nil)
        end
        if frame.SetBackdropColor then
            pcall(frame.SetBackdropColor, frame, 0, 0, 0, 0)
        end
        hideTextureRegions(frame)

        if frame.GetChildren then
            for _, child in pairs({ frame:GetChildren() }) do
                -- This subtree is the zone-name widget; remove all texture
                -- regions in it while leaving FontStrings untouched.
                hideZoneArt(child, seen)
            end
        end
    end

    local zoneFrames = {
        MinimapZoneTextButton,
        MinimapZoneTextFrame,
        MinimapZoneTextBackground,
        MinimapCluster and MinimapCluster.ZoneTextButton,
        MinimapCluster and MinimapCluster.ZoneTextFrame,
        MinimapCluster and MinimapCluster.ZoneText,
        -- The zone button sits over the separate minimap header strip.
        MinimapCluster and MinimapCluster.BorderTop,
        MinimapBorderTop,
        -- Current Blizzard minimap keeps its bottom label plate here.
        MinimapCluster and MinimapCluster.BorderBottom,
    }
    local seenZones = {}
    for _, frame in pairs(zoneFrames) do
        hideZoneArt(frame, seenZones)
    end

    -- On the current UI, the zone label is a FontString hosted by an
    -- unnamed frame separate from the clickable ZoneTextButton. Strip that
    -- small host's textures too, while leaving the FontString visible.
    local zoneText = MinimapCluster and MinimapCluster.ZoneText or MinimapZoneText
    local zoneTextParent = zoneText and zoneText.GetParent and zoneText:GetParent()
    if zoneTextParent and zoneTextParent ~= MinimapCluster and zoneTextParent ~= Minimap then
        hideZoneArt(zoneTextParent, seenZones)
    end

    local function findZoneWidgets(root, visited)
        if not root or visited[root] then return end
        visited[root] = true
        local name = root.GetName and root:GetName()
        name = name and name:lower() or ""
        if name:find("zonetext", 1, true)
            or (name:find("zone", 1, true) and name:find("background", 1, true)) then
            hideZoneArt(root, seenZones)
        end
        if root.GetChildren then
            for _, child in pairs({ root:GetChildren() }) do
                findZoneWidgets(child, visited)
            end
        end
    end
    findZoneWidgets(MinimapCluster, {})

    local function findNamedFrame(root, word, seen)
        if not root or seen[root] then return nil end
        seen[root] = true
        local name = root.GetName and root:GetName()
        if name and name:lower():find(word, 1, true) then
            return root
        end
        if root.GetChildren then
            for _, child in pairs({ root:GetChildren() }) do
                local found = findNamedFrame(child, word, seen)
                if found then return found end
            end
        end
    end

    local function findMinimapControl(word)
        local direct
        if word == "mail" then
            direct = (MinimapCluster and MinimapCluster.IndicatorFrame
                and MinimapCluster.IndicatorFrame.MailFrame)
                or MiniMapMailFrame
                or (MinimapCluster and MinimapCluster.MailFrame)
        else
            local tracking = MinimapCluster and MinimapCluster.Tracking
            direct = (tracking and tracking.Button)
                or MiniMapTrackingButton
                or MiniMapTracking
                or (MinimapCluster and (MinimapCluster.TrackingButton or tracking))
        end
        return direct or findNamedFrame(MinimapCluster, word, {})
            or findNamedFrame(Minimap, word, {})
    end

    local mailButton = findMinimapControl("mail")
    local trackingButton = findMinimapControl("tracking")
    if mailButton and trackingButton and mailButton.ClearAllPoints and mailButton.SetPoint then
        local function placeMail()
            if not mailButton.IsShown or mailButton:IsShown() then
                mailButton:ClearAllPoints()
                mailButton:SetPoint("RIGHT", trackingButton, "LEFT", -3, 0)
            end
        end

        if not mailButton.pfsMailPositionHooked then
            mailButton.pfsMailPositionHooked = true
            mailButton.pfsPlacingMail = false
            if hooksecurefunc then
                hooksecurefunc(mailButton, "SetPoint", function()
                    if mailButton.pfsPlacingMail then return end
                    C_Timer.After(0, function()
                        if mailButton.pfsPlacingMail then return end
                        mailButton.pfsPlacingMail = true
                        placeMail()
                        mailButton.pfsPlacingMail = false
                    end)
                end)
            end
            if mailButton.HookScript then
                mailButton:HookScript("OnShow", function()
                    C_Timer.After(0, function()
                        mailButton.pfsPlacingMail = true
                        placeMail()
                        mailButton.pfsPlacingMail = false
                    end)
                end)
            end
        end

        mailButton.pfsPlacingMail = true
        placeMail()
        mailButton.pfsPlacingMail = false
    end
end

local function refreshVisualAdjustments()
    applyQuestTrackerStyle()
    removeDamageMeterArt()
    applyMinimapAdjustments()
end

local visualAdjustmentEvents = CreateFrame("Frame")
visualAdjustmentEvents:RegisterEvent("PLAYER_LOGIN")
visualAdjustmentEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
visualAdjustmentEvents:RegisterEvent("ADDON_LOADED")
visualAdjustmentEvents:RegisterEvent("ZONE_CHANGED")
visualAdjustmentEvents:RegisterEvent("ZONE_CHANGED_INDOORS")
visualAdjustmentEvents:RegisterEvent("ZONE_CHANGED_NEW_AREA")
visualAdjustmentEvents:SetScript("OnEvent", function(_, event, addonName)
    if event == "ADDON_LOADED"
        and addonName ~= "Blizzard_DamageMeter"
        and addonName ~= "Blizzard_ObjectiveTracker"
        and addonName ~= "Blizzard_Minimap" then
        return
    end

    C_Timer.After(0, refreshVisualAdjustments)
    C_Timer.After(0.5, refreshVisualAdjustments)
    C_Timer.After(1.5, refreshVisualAdjustments)
end)

-- Live minimap diagnostics for clients whose UI/addons replace Blizzard's
-- minimap widgets. This lets us target the exact frames instead of guessing.
local function describeMinimapObject(label, object)
    if not object then
        printMessage(label .. ": not found")
        return
    end

    local name = object.GetName and object:GetName() or "(unnamed)"
    local objectType = object.GetObjectType and object:GetObjectType() or "Frame"
    local parent = object.GetParent and object:GetParent()
    local parentName = parent and parent.GetName and parent:GetName() or "(no named parent)"
    local shown = object.IsShown and tostring(object:IsShown()) or "unknown"
    local point, relativeTo, relativePoint, x, y
    if object.GetPoint then
        point, relativeTo, relativePoint, x, y = object:GetPoint(1)
    end
    local anchor = point and string.format("%s -> %s:%s (%s,%s)", point,
        relativeTo and relativeTo.GetName and relativeTo:GetName() or "(nil)",
        tostring(relativePoint), tostring(x), tostring(y)) or "(no point)"
    printMessage(string.format("%s: %s [%s], parent=%s, shown=%s, anchor=%s",
        label, name, objectType, parentName, shown, anchor))

    if object.GetRegions then
        for _, region in pairs({ object:GetRegions() }) do
            if region and region.GetObjectType and region:GetObjectType() == "Texture" then
                local regionName = region.GetName and region:GetName() or "(unnamed texture)"
                local atlas = region.GetAtlas and region:GetAtlas()
                local texture = region.GetTexture and region:GetTexture()
                local regionShown = region.IsShown and tostring(region:IsShown()) or "unknown"
                printMessage(string.format("  texture %s shown=%s atlas=%s texture=%s",
                    regionName, regionShown, tostring(atlas), tostring(texture)))
            end
        end
    end
end

SLASH_FOREVERPERSONALUIADJUSTMENTS1 = "/fpuia"
SlashCmdList.FOREVERPERSONALUIADJUSTMENTS = function(message)
    local command = (message or ""):lower():match("^%s*(.-)%s*$")
    if command == "minimap" then
        applyMinimapAdjustments()
        printMessage("reapplied minimap adjustments")
    elseif command == "minimapdiag" then
        local cluster = MinimapCluster
        local zoneText = cluster and cluster.ZoneText or MinimapZoneText
        describeMinimapObject("ZoneTextButton", cluster and cluster.ZoneTextButton or MinimapZoneTextButton)
        describeMinimapObject("ZoneText", zoneText)
        describeMinimapObject("ZoneTextParent", zoneText and zoneText.GetParent and zoneText:GetParent())
        describeMinimapObject("BorderBottom", cluster and cluster.BorderBottom)
        describeMinimapObject("MailFrame", cluster and cluster.IndicatorFrame
            and cluster.IndicatorFrame.MailFrame or MiniMapMailFrame)
        describeMinimapObject("TrackingButton", cluster and cluster.Tracking
            and cluster.Tracking.Button or MiniMapTrackingButton)
    else
        printMessage("use /fpuia minimap to reapply or /fpuia minimapdiag to report the live minimap frames")
    end
end
